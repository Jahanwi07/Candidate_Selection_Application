import os
from flask import Flask, request, jsonify
import openai
from dotenv import load_dotenv
import pandas as pd
import json

load_dotenv()

app = Flask(__name__)

class OpenAIHandler:
    def __init__(self):
        self.api_key = "your_api_key"
        self.init_openai()

    def init_openai(self):
        os.environ['OPENAI_API_TYPE'] = "azure"
        os.environ['OPENAI_API_VERSION'] = "2023-03-15-preview"
        os.environ['OPENAI_API_BASE'] = "https://bc-api-management-uksouth.azure-api.net"
        os.environ['OPENAI_API_KEY'] = self.api_key

    def generate_openai_response(self, df):
       
        individual_scores = [
            df["Humility"]["index_score"],
            df["Growth"]["index_score"],
            df["Resilience"]["index_score"],
            df["Attitude to Failure"]["index_score"],
            df["Fixed Beliefs"]["index_score"],
            df["Curiosity"]["index_score"],
            df["Blame"]["index_score"],
            df["Agility"]["index_score"],
            df["Collaboration"]["index_score"],
            df["Conscientiousness"]["index_score"],
            df["Embracing Data"]["index_score"],
            df["Generosity"]["index_score"],
            df["Nimbleness"]["index_score"],
            df["Seeking Diversity"]["index_score"]    
        ]
        print(individual_scores)
        categories = ['Humility', 'Growth', 'Resilience', 'Attitude to Failure', 'Fixed Beliefs', 'Curiosity', 'Blame',
                    'Agility', 'Collaboration','Conscientiousness', 'Embracing Data', 'Generosity', 'Nimbleness', 'Seeking Diversity' ]
        
        prompt = f'''
        Humility: The ability to recognize and accept one's limitations and mistakes without arrogance or excessive pride.
        Growth: The continuous process of personal or professional development and improvement over time.
        Resilience: The capacity to bounce back and recover quickly from setbacks, adversity, or difficult situations.
        Attitude to Failure: The mindset and perspective one holds towards failures, seeing them as learning opportunities 
        rather than permanent setbacks.
        Fixed Beliefs: Strongly held opinions or convictions that are resistant to change, even in the face of contradictory 
        evidence.
        Curiosity: A strong desire to explore, learn, and seek new knowledge or experiences.
        Blame: Assigning responsibility or fault to someone for a particular situation or outcome.
        Agility: The ability to adapt quickly and effectively to changing circumstances or challenges.
        Collaboration: Working together with others towards a common goal, sharing ideas, resources, and responsibilities.
        Conscientiousness: The dedication to meticulousness and responsibility in all endeavors, ensuring nothing is left to chance.
        Embracing Data: The practice of harnessing the power of data to drive informed decisions and innovations.
        Generosity: The art of giving freely, expecting nothing in return, and enriching both oneself and others through acts of kindness.
        Nimbleness: The agility and adaptability to swiftly navigate change, seizing opportunities with finesse and precision.
        Seeking Diversity: The commitment to embracing a broad range of perspectives, experiences, and backgrounds, recognizing the strength in our differences.

        In a growth mindset Assessment Test where the candidate is scored based on the above parameters, the candidate has performed as follows:

        Individual Category:

        These are the index scores:
        Humility: {df["Humility"]["index_score"]}
        Growth:  {df["Growth"]["index_score"]}
        Resilience: {df["Resilience"]["index_score"]}
        Attitude to Failure:{df["Attitude to Failure"]["index_score"]}
        Fixed Beliefs: {df["Fixed Beliefs"]["index_score"]}
        Curiosity: {df["Curiosity"]["index_score"]}
        Blame: {df["Blame"]["index_score"]}
        Agility: {df["Agility"]["index_score"]}
        Collaboration: {df["Collaboration"]["index_score"]}
        Conscientiousness: {df["Conscientiousness"]["index_score"]}
        Embracing Data: {df["Embracing Data"]["index_score"]}
        Generosity: {df["Generosity"]["index_score"]}
        Nimbleness: {df["Nimbleness"]["index_score"]}
        Seeking Diversity: {df["Seeking Diversity"]["index_score"]}



        **RULES** = if index_score 0-60 he/she is marked as LOW
                if index_score 60-80 he/she is marked as MEDIUM
                if index_score 80-100 he/she is marked as HIGH.
        '''

        prompt1 = f'''Comment and give me a comprehensive interview question to ask the candidate, based of the data on their individual,
        grades of each and every {categories} individually.
        The question should be with respect to the analysis you developed through your comment and their scores in the 
        assessment.
        Also explain your reasoning behind your question and its relevance to your comment.
        Write comment, question and reasoning separately for each and every value in {categories}.
        The output should be in the following json format so that it will be list of objects:
        [
    
        "category": "Humility",
        "score_level": "MEDIUM",
        "comment": "The candidate's Humility score is MEDIUM.",
        "question": "Can you provide an example of a time related to Humility and how you dealt with it?",
        "reasoning": "This question will allow the candidate to demonstrate their level of Humility and their ability to respond effectively."
    ,
    
        "category": "Growth",
        "score_level": "MEDIUM",
        "comment": "The candidate's Growth score is MEDIUM.",
        "question": "Can you provide an example of a time related to Growth and how you dealt with it?",
        "reasoning": "This question will allow the candidate to demonstrate their level of Growth and their ability to respond effectively."
    
    # ... (similar objects for other categories)
]
            
        '''

        response1 = openai.ChatCompletion.create(
            engine="gpt-35-turbo",
            messages=[
                    {"role": "system", "content": f"{prompt}"},
                    {"role": "user", "content": f"{prompt1}"}
                ]
            )
        # return response1['choices'][0]['message']['content']
    
        output_string = f""" {response1['choices'][0]['message']['content']} """

        # Parse the JSON string into a list of dictionaries
        output_list = json.loads(output_string)

        return output_list


class DataExtractor:
    @staticmethod
    def extract_scores(data):
        strn = data

        key_val = {}
        rl_val = {}

        def extractKeyVal(obj):
            if type(obj) is dict:
                for key, value in obj.items():
                    key_val.update({key: value})
                    extractKeyVal(value)

            elif type(obj) is list:
                for item in obj:
                    extractKeyVal(item)

        extractKeyVal(strn)

        for item in key_val["personal_scores"]:
            rl_val.update({item["category_name"]: {}})

        for item in key_val["personal_scores"]:
            rl_val[item["category_name"]].update({"index_score": item["index_score"]})

        return pd.DataFrame.from_dict(rl_val)


openai_handler = OpenAIHandler()

@app.route('/generate_response', methods=['POST'])
def generate_response():
    try:
        input_data = request.get_json()
        df = DataExtractor.extract_scores(input_data)
        openai_output = openai_handler.generate_openai_response(df)
        
        output_data = {
            "data": {
                "openai_output": openai_output
            },
            "message": "Success"
        }
        return jsonify(output_data), 200
    except Exception as e:
        error_data = {
            "message": "Error",
            "details": str(e)
        }
        return jsonify(error_data), 500

if __name__ == '__main__':
    app.run(debug=True)