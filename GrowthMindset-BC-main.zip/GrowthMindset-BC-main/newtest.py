import os
import json
from flask import Flask, request, jsonify
import openai
from dotenv import load_dotenv
import pandas as pd

load_dotenv()

app = Flask(__name__)

openai.api_key = os.environ["OPENAI_API_KEY"]

def extract_scores(data):
    key_val = {}
    rl_val = {}

    def extractKeyVal(obj):
        if type(obj) is dict:
            for key, value in obj.items():
                key_val.update({key: value})
                extractKeyVal(value)

        elif type(obj) is list:
            for item in obj:
                extractKeyVal(item)

    # Remove this line: strn = json.load(data)
    # Use the provided JSON data directly
    strn = data

    extractKeyVal(strn)

    for item in key_val["personal_scores"]:
        rl_val.update({item["category_name"]: {}})

    for item in key_val["personal_scores"]:
        rl_val[item["category_name"]].update({"hml_score": item["hml_score"]})
        rl_val[item["category_name"]].update({"team_overall_position": item["team_overall_position"]})
        rl_val[item["category_name"]].update({"team_relative_position": item["team_relative_position"]})

    return pd.DataFrame.from_dict(rl_val)
def generate_openai_response(df):
    score_mapping = {'low': 1, 'medium': 2, 'high': 3}
    individual_scores = [
        score_mapping[df["Humility"]["hml_score"].lower()],  # Convert to lowercase and update mapping usage
        score_mapping[df["Growth"]["hml_score"].lower()],
        score_mapping[df["Resilience"]["hml_score"].lower()],
        score_mapping[df["Attitude to Failure"]["hml_score"].lower()],
        score_mapping[df["Fixed Beliefs"]["hml_score"].lower()],
        # score_mapping[df.FB_hml_rating[num].values[0].lower()],
        score_mapping[df["Curiosity"]["hml_score"].lower()],
        score_mapping[df["Blame"]["hml_score"].lower()],
        score_mapping[df["Agility"]["hml_score"].lower()],
        score_mapping[df["Collaboration"]["hml_score"].lower()]
    ]
    print(individual_scores)
    # plt.figure(figsize=(10, 6))
    categories = ['Humility', 'Growth', 'Resilience', 'Attitude to Failure', 'Fixed Beliefs', 'Curiosity', 'Blame',
                'Agility', 'Collaboration']
    
    #in following 
    prompt = f'''
    Humility: The ability to recognize and accept one's limitations and mistakes without arrogance or excessive pride.
    Growth: The continuous process of personal or professional development and improvement over time.
    Resilience: The capacity to bounce back and recover quickly from setbacks, adversity, or difficult situations.
    Attitude to Failure: The mindset and perspective one holds towards failures, seeing them as learning opportunities 
    rather than permanent setbacks.
    Fixed Beliefs: Strongly held opinions or convictions that are resistant to change, even in the face of contradictory 
    evidence.
    Curiosity: A strong desire to explore, learn, and seek new knowledge or experiences.
    Blame: Assigning responsibility or fault to someone for a particular situation or outcome.
    Agility: The ability to adapt quickly and effectively to changing circumstances or challenges.
    Collaboration: Working together with others towards a common goal, sharing ideas, resources, and responsibilities.

    In a growth mindset Assessment Test where the candidate is scored based on the above parameters, the candidate has performed as follows:

    Individual Category:

    Humility: {df["Humility"]["hml_score"]}
    Growth:  {df["Growth"]["hml_score"]}
    Resilience: {df["Resilience"]["hml_score"]}
    Attitude to Failure:{df["Attitude to Failure"]["hml_score"]}
    Fixed Beliefs: {df["Fixed Beliefs"]["hml_score"]}
    Curiosity: {df["Curiosity"]["hml_score"]}
    Blame: {df["Blame"]["hml_score"]}
    Agility: {df["Agility"]["hml_score"]}
    Collaboration: {df["Collaboration"]["hml_score"]}

    When compared against their team members, the candidates team-relative scores are:

    Humility: {df["Humility"]["team_relative_position"]}
    Growth: {df["Growth"]["team_relative_position"]}
    Resilience: {df["Resilience"]["team_relative_position"]}
    Attitude to Failure: {df["Attitude to Failure"]["team_relative_position"]}
    Fixed Beliefs: {df["Fixed Beliefs"]["team_relative_position"]}
    Curiosity: {df["Curiosity"]["team_relative_position"]}
    Blame:{df["Blame"]["team_relative_position"]}
    Agility: {df["Agility"]["team_relative_position"]}
    Collaboration: {df["Collaboration"]["team_relative_position"]}

    And their team-overall scores are:

    Humility: {df["Humility"]["team_overall_position"]}
    Growth: {df["Growth"]["team_overall_position"]}
    Resilience: {df["Resilience"]["team_overall_position"]}
    Attitude to Failure: {df["Attitude to Failure"]["team_overall_position"]}
    Fixed Beliefs: {df["Fixed Beliefs"]["team_overall_position"]}
    Curiosity: {df["Curiosity"]["team_overall_position"]}
    Blame: {df["Blame"]["team_overall_position"]}
    Agility: {df["Agility"]["team_overall_position"]}
    Collaboration: {df["Collaboration"]["team_overall_position"]}'''

    prompt1 = f'''Comment and give me a comprehensive interview question to ask the candidate, based of the data on their individual,
    team-relative and team-overall grades of each and every {categories} individually.
    The question should be with respect to the analysis you developed through your comment and their scores in the 
    assessment.
    Also explain your reasoning behind your question and its relevance to your comment.
    Write comment, question and reasoning separately for each and every value in {categories}.
    The output should be in the following format:
    value:fill in the score

    Comment: fill in the comment

    Question: fill in the question

    Reasoning: fill in the reasoning
    '''

    response1 = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
                {"role": "system", "content": f"{prompt}"},
                {"role": "user", "content": f"{prompt1}"}
            ]
        )
    return response1['choices'][0]['message']['content']
@app.route('/generate_response', methods=['POST'])
def generate_response():
    try:
        input_data = request.json
        df = extract_scores(input_data)
        openai_output = generate_openai_response(df)
        
        output_data = {
            "data": {
                "openai_output": openai_output
            },
            "message": "Success"
        }
        
        return jsonify(output_data), 200
    except Exception as e:
        error_data = {
            "message": "Error",
            "details": str(e)
        }
        return jsonify(error_data), 500

if __name__ == '__main__':
    app.run(debug=True)
