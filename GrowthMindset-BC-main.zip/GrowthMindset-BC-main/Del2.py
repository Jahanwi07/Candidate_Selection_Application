import os
from flask import Flask, request, jsonify
import openai
from dotenv import load_dotenv
import pandas as pd
import json

load_dotenv()

app = Flask(__name__) 

class OpenAIHandler:
    def __init__(self):
        self.api_key = "your_api_key"
        self.init_openai()

    def init_openai(self):
        os.environ['OPENAI_API_TYPE'] = "azure"
        os.environ['OPENAI_API_VERSION'] = "2023-03-15-preview"
        os.environ['OPENAI_API_BASE'] = "https://bc-api-management-uksouth.azure-api.net"
        os.environ['OPENAI_API_KEY'] = self.api_key



    def generate_openai_response(self, df):
        categories = ['Humility', 'Growth', 'Resilience', 'Attitude to Failure', 'Fixed Beliefs', 'Curiosity', 'Blame',
                    'Agility', 'Collaboration','Conscientiousness', 'Embracing Data', 'Generosity', 'Nimbleness', 'Seeking Diversity' ]
        
        output_format = '''
            [
                
                {
                    "category": "overall"
                    "interpretation": "Give detail interpretation so that it covers each and every aspect of the group of candidates.
                }
            ]
                        '''
        
        prompt = f'''
        Humility: The ability to recognize and accept one's limitations and mistakes without arrogance or excessive pride.
        Growth: The continuous process of personal or professional development and improvement over time.
        Resilience: The capacity to bounce back and recover quickly from setbacks, adversity, or difficult situations.
        Attitude to Failure: The mindset and perspective one holds towards failures, seeing them as learning opportunities 
        rather than permanent setbacks.
        Fixed Beliefs: Strongly held opinions or convictions that are resistant to change, even in the face of contradictory 
        evidence.
        Curiosity: A strong desire to explore, learn, and seek new knowledge or experiences.
        Blame: Assigning responsibility or fault to someone for a particular situation or outcome.
        Agility: The ability to adapt quickly and effectively to changing circumstances or challenges.
        Collaboration: Working together with others towards a common goal, sharing ideas, resources, and responsibilities.
        Conscientiousness: The dedication to meticulousness and responsibility in all endeavors, ensuring nothing is left to chance.
        Embracing Data: The practice of harnessing the power of data to drive informed decisions and innovations.
        Generosity: The art of giving freely, expecting nothing in return, and enriching both oneself and others through acts of kindness.
        Nimbleness: The agility and adaptability to swiftly navigate change, seizing opportunities with finesse and precision.
        Seeking Diversity: The commitment to embracing a broad range of perspectives, experiences, and backgrounds, recognizing the strength in our differences.

        In a growth mindset Assessment Test where the candidates are scored based on the above parameters, candidates have performed as follows:

        **Group level averages:

        {df} **

        '''

        prompt1 = f'''Comment and give me a comprehensive high level interpretation json about the group of people, based of the data on their Group level averages.

        The interpretation should be with respect to the analysis you developed through your comment and their average scores in the 
        assessment.
        Write interpretaion for all {categories} in a single paragraph.
        This paragraph should explain clearly the group level analysis of each and every {categories}.
        The output should strictly be in the following json format so that it will be list of objects:
        {output_format}
            
        '''

        response1 = openai.ChatCompletion.create(
            engine="gpt-35-turbo",
            messages=[
                    {"role": "system", "content": f"{prompt}"},
                    {"role": "user", "content": f"{prompt1}"}
                ]
            )
        # return response1['choices'][0]['message']['content']
    
        output_string = f""" {response1['choices'][0]['message']['content']} """

        # Parse the JSON string into a list of dictionaries
        output_list = json.loads(output_string)

        return output_list


class DataExtractor:
    @staticmethod
    def extract_scores(data):
        output_list = []
        for item in data["objects"]:
            category_name = item["category"]
            index_score_value = item["index_score"]
            output_list.append({"Category": category_name, "Index Score": index_score_value})

        
        return output_list


openai_handler = OpenAIHandler()

@app.route('/generate_response', methods=['POST'])
def generate_response():
    try:
        input_data = request.get_json()
        df = DataExtractor.extract_scores(input_data)
        openai_output = openai_handler.generate_openai_response(df)
        
        output_data = {
            "data": {
                "openai_output": openai_output
            },
            "message": "Success"
        }
        return jsonify(output_data), 200
    except Exception as e:
        error_data = {
            "message": "Error",
            "details": str(e)
        }
        return jsonify(error_data), 500

if __name__ == '__main__':
    app.run(debug=True)
