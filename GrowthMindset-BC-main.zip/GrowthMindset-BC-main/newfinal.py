import pandas as pd
import openai
import os
import json
import streamlit as st
import plotly.express as px
from dotenv import load_dotenv

load_dotenv()

openai.api_key = os.environ["OPENAI_API_KEY"]


#return a dictionary of dictionary of structure {"categor": {"hml_score": "value", "team_rel...."}}
def extractInfo(filePath):
    with open(filePath, "r") as file:
        strn = json.load(file)

    key_val= {}
    rl_val= {}

    def extractKeyVal(obj):
        if type(obj) is dict:
            for key, value in obj.items():
                key_val.update({key: value})
                extractKeyVal(value)
        
        elif type(obj) is list:
            for item in obj:
                extractKeyVal(item)

    extractKeyVal(strn)

    for item in key_val["personal_scores"]:
        rl_val.update({item["category_name"]: {}})
        
    for item in key_val["personal_scores"]:
        rl_val[item["category_name"]].update({"hml_score": item["hml_score"]})
        rl_val[item["category_name"]].update({"team_overall_position": item["team_overall_position"]})
        rl_val[item["category_name"]].update({"team_relative_position": item["team_relative_position"]})
    
    return pd.DataFrame.from_dict(rl_val)
        


        


# df = pd.read_csv('Book.csv')

with st.form(key='form'):
    name = st.selectbox("Select Candidate: ", ["63e4dc4f-1eed-43ea-a0d9-27fb694d11d5","808a58ab-acec-44bc-a9f2-b4072199898a", "d81089f1-d592-4c15-a7a5-86c4550b6999"])
    # category = st.selectbox("Choose Value: ",
    #                         ['Humility', 'Growth', 'Resilience', 'Attitude to Failure', 'Fixed Beliefs', 'Curiosity',
    #                          'Blame', 'Agility', 'Collaboration'])
    submit_button = st.form_submit_button(label='Submit')
# num = df[df['Firstname'] == name].index.values

df = extractInfo(name+".json")

score_mapping = {'low': 1, 'medium': 2, 'high': 3}
individual_scores = [
    score_mapping[df["Humility"]["hml_score"].lower()],  # Convert to lowercase and update mapping usage
    score_mapping[df["Growth"]["hml_score"].lower()],
    score_mapping[df["Resilience"]["hml_score"].lower()],
    score_mapping[df["Attitude to Failure"]["hml_score"].lower()],
    score_mapping[df["Fixed Beliefs"]["hml_score"].lower()],
    # score_mapping[df.FB_hml_rating[num].values[0].lower()],
    score_mapping[df["Curiosity"]["hml_score"].lower()],
    score_mapping[df["Blame"]["hml_score"].lower()],
    score_mapping[df["Agility"]["hml_score"].lower()],
    score_mapping[df["Collaboration"]["hml_score"].lower()]
]
print(individual_scores)
# plt.figure(figsize=(10, 6))
categories = ['Humility', 'Growth', 'Resilience', 'Attitude to Failure', 'Fixed Beliefs', 'Curiosity', 'Blame',
              'Agility', 'Collaboration']
fig = px.line_polar(df, r=individual_scores, theta=categories, line_close=True)
fig.update_traces(fill='toself')
# fig.update_polars(radialaxis_showline=False)
# fig.update_polars(radialaxis_showticklabels=False)
# fig.update_layout(polar_radialaxis_showticklabels=False)
fig.update_layout(
    polar_radialaxis_showticklabels=True,
    polar_radialaxis_nticks=3,  # Set the number of ticks
    polar_radialaxis_tickvals=[1, 2, 3],  # Specify the tick values
    polar_radialaxis_ticktext=['1', '2', '3']  # Specify the corresponding tick labels
)
# fig.show()
# plt.bar(categories, individual_scores)
# plt.xlabel('Categories')
# plt.ylabel('Scores')
# plt.title('Candidate Scores in Individual Category')
# plt.xticks(rotation=45)

#in following 
prompt = f'''
Humility: The ability to recognize and accept one's limitations and mistakes without arrogance or excessive pride.
Growth: The continuous process of personal or professional development and improvement over time.
Resilience: The capacity to bounce back and recover quickly from setbacks, adversity, or difficult situations.
Attitude to Failure: The mindset and perspective one holds towards failures, seeing them as learning opportunities 
rather than permanent setbacks.
Fixed Beliefs: Strongly held opinions or convictions that are resistant to change, even in the face of contradictory 
evidence.
Curiosity: A strong desire to explore, learn, and seek new knowledge or experiences.
Blame: Assigning responsibility or fault to someone for a particular situation or outcome.
Agility: The ability to adapt quickly and effectively to changing circumstances or challenges.
Collaboration: Working together with others towards a common goal, sharing ideas, resources, and responsibilities.

In a growth mindset Assessment Test where the candidate is scored based on the above parameters, the candidate 
# {name}  has performed as follows:

Individual Category:

Humility: {df["Humility"]["hml_score"]}
Growth:  {df["Growth"]["hml_score"]}
Resilience: {df["Resilience"]["hml_score"]}
Attitude to Failure:{df["Attitude to Failure"]["hml_score"]}
Fixed Beliefs: {df["Fixed Beliefs"]["hml_score"]}
Curiosity: {df["Curiosity"]["hml_score"]}
Blame: {df["Blame"]["hml_score"]}
Agility: {df["Agility"]["hml_score"]}
Collaboration: {df["Collaboration"]["hml_score"]}

When compared against their team members, the candidates team-relative scores are:

Humility: {df["Humility"]["team_relative_position"]}
Growth: {df["Growth"]["team_relative_position"]}
Resilience: {df["Resilience"]["team_relative_position"]}
Attitude to Failure: {df["Attitude to Failure"]["team_relative_position"]}
Fixed Beliefs: {df["Fixed Beliefs"]["team_relative_position"]}
Curiosity: {df["Curiosity"]["team_relative_position"]}
Blame:{df["Blame"]["team_relative_position"]}
Agility: {df["Agility"]["team_relative_position"]}
Collaboration: {df["Collaboration"]["team_relative_position"]}

And their team-overall scores are:

Humility: {df["Humility"]["team_overall_position"]}
Growth: {df["Growth"]["team_overall_position"]}
Resilience: {df["Resilience"]["team_overall_position"]}
Attitude to Failure: {df["Attitude to Failure"]["team_overall_position"]}
Fixed Beliefs: {df["Fixed Beliefs"]["team_overall_position"]}
Curiosity: {df["Curiosity"]["team_overall_position"]}
Blame: {df["Blame"]["team_overall_position"]}
Agility: {df["Agility"]["team_overall_position"]}
Collaboration: {df["Collaboration"]["team_overall_position"]}'''

prompt1 = f'''Comment and give me a comprehensive interview question to ask the candidate, based of the data on their individual,
team-relative and team-overall grades of each and every {categories} individually.
The question should be with respect to the analysis you developed through your comment and their scores in the 
assessment.
Also explain your reasoning behind your question and its relevance to your comment.
Write comment, question and reasoning separately for each and every value in {categories}.
The output should be in the following format:
value:fill in the score

Comment: fill in the comment

Question: fill in the question

Reasoning: fill in the reasoning
'''

# print(prompt)
# print(num)
if submit_button:
    # response = openai.Completion.create(
    #     model="text-davinci-003",
    #     prompt=prompt,
    #     temperature=1,
    #     max_tokens=256,
    #     top_p=1,
    #     frequency_penalty=0,
    #     presence_penalty=0
    # )

    response1 = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
                {"role": "system", "content": f"{prompt}"},
                {"role": "user", "content": f"{prompt1}"}
            ]
        )


    st.plotly_chart(fig)
    # st.write(response['choices'][0]['text'])
    st.write(response1['choices'][0]['message']['content'])